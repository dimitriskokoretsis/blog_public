# Biscuits with 2 sides are defined (vectors with 2 elements)
biscuit.1 <- c("chocolate","chocolate")
biscuit.2 <- c("chocolate","icing")
biscuit.3 <- c("icing","icing")

# and placed in a list named "box".
box <- list(biscuit.1,biscuit.2,biscuit.3)