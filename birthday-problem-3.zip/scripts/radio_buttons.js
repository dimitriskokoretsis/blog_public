const radioButtons = document.querySelectorAll("input[name='constraints-blog-part']");
for(const radioButton of radioButtons){
  radioButton.addEventListener("click", showSelected);
};
function showSelected() {
  if (this.checked) {
    document.getElementById("img-constraints").setAttribute("src", "images/constraints-" + this.value + ".png");
  };
};