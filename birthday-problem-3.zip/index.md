---
title: "The birthday problem — Part 3: Calculating in steps"
author: "Dimitris Kokoretsis"
date: "2026-06-01"
sitemap:
  priority: 1
useRelativeCover: true
cover: "cover.png"
header:
  image: "thumbnail.png"
source_link: true
mathjax: true
tags:
  - birthday-problem
  - probability
  - combinatorics
  - recursive-formula
  - r-programming
coderefs:
  - data-tables
  - sequences
  - column-operations
  - functions
  - vectors
---

<link href="{{< blogdown/postref >}}index_files/htmltools-fill/fill.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/htmlwidgets/htmlwidgets.js"></script>

<script src="{{< blogdown/postref >}}index_files/plotly-binding/plotly.js"></script>

<script src="{{< blogdown/postref >}}index_files/typedarray/typedarray.min.js"></script>

<script src="{{< blogdown/postref >}}index_files/jquery/jquery.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/crosstalk/css/crosstalk.min.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/crosstalk/js/crosstalk.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/plotly-htmlwidgets-css/plotly-htmlwidgets.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/plotly-main/plotly-latest.min.js"></script>

*“Good, fast, cheap. Choose two.”* In other words, quality is often expensive and takes time. And sometimes quick and cheap solutions of lower quality are sufficient.

This **choice** is the point of this [series](/tags/birthday-problem/) on the *birthday problem*:

> What’s the probability that two students in a classroom share a common birthday?

After failing in [part 1](/posts/birthday-problem-1/) due to an unreasonably *expensive* method, we took a cheaper shortcut in [part 2](/posts/birthday-problem-2/) and got *approximate* results as a trade-off.

In this final part, we’ll spend some *time* understanding the problem to calculate precise results.<!--more-->

## Previously in the series

So far, we’ve bypassed the problem’s nature and reshaped it into one of data engineering:

- [Part 1](/posts/birthday-problem-1/): **Counting**. We tried to recreate and analyze all possible combinations of birthdays. This gives precise results but needs huge amounts of computer memory. So we could only find results for 2 or 3 students.

  - 2 students: *P<sub>common birthday,2</sub>* = 0.27% or 0.0027
  - 3 students: *P<sub>common birthday,3</sub>* = 0.82% or 0.0082

- [Part 2](/posts/birthday-problem-2/): **Sampling**, also known as the <a href="https://en.wikipedia.org/wiki/Monte_Carlo_method" target="_blank">Monte Carlo method</a>. We recreated and analyzed a *random sample* of all possible combinations. This did give *approximate* results: the probability quickly becomes surprisingly high (higher than 50% or 0.5 for just 23 students).

In this part, we’ll find precise results by embracing the problem’s true nature: combinatorics.

## Opposite event: *no common birthday*

Imagine a classroom with an arbitrary number of students. Let’s call that number *n*. We want to find the probability of **at least one common birthday** between any pair of them.

The number of possible pairs can be as low as 1 (if *n=2*) to as high as… well, a lot.

We *could* calculate the number of student pairs and this probability directly, but there’s a much easier path: find the probability of the exact opposite event.

> *P<sub>no common birthday</sub>*: probability of *no common birthday* existing. In other words, *all birthdays are unique*.

Because these are opposite events, **their probabilities add up to 1**. We can take advantage of this to find *P<sub>common birthday</sub>*:

<div class="figure">

<img src="images/venn_no_common_birthday.png" alt="&lt;a href='https://en.wikipedia.org/wiki/Venn_diagram' target='_blank'&gt;Venn diagram&lt;/a&gt; showing the events of *common birthday* (white area) and *no common birthday* (grey area), and their probabilities. Whole area of the diagram is equal to 1." width="100%" />
<p class="caption">

<span id="fig:unnamed-chunk-3"></span>Figure 1: <a href='https://en.wikipedia.org/wiki/Venn_diagram' target='_blank'>Venn diagram</a> showing the events of *common birthday* (white area) and *no common birthday* (grey area), and their probabilities. Whole area of the diagram is equal to 1.
</p>

</div>

## **Math:** building the formula

To build the formula for *P<sub>no common birthday</sub>*, let’s start so small that it’s silly and trivial.

We’ll start from the smallest possible classroom of just 1 student, and gradually build it by adding more.

For all birthdays to be unique, each added student can “draw” from a limited **pool of available birthdays**. We’ll keep track of this pool as the number of students increases.

### 1 student

This lone student can have any birthday throughout the year, so the pool of available birthdays is **365** out of 365.
`$$P_{no~common~birthday,1} = \frac{365}{365} = 1$$`

It’s obviously certain (probability=1) that this student’s birthday will be unique because *there is no one else*.

### 2 students

Let’s add one student, meaning 2 in total.

The available birthdays for this added student are **not** 365, because it must be different from the existing one.

So the probability of no common birthday between these 2 students is:
`$$P_{no~common~birthday,2} = \frac{365 - 1}{365} \approx 0.9973$$`

To make sure we’re on the right track, we can crosscheck with the precise *P<sub>common birthday,2</sub>* we calculated in
part 1 (0.0027).
`$$P_{common~birthday,2} = 1 - P_{no~common~birthday,2} \approx 1 - 0.9973 = 0.0027$$`

It matches so far, let’s try one more.

### 3 students

Having 3 students with unique birthdays requires two events to occur at the same time:

- Event 1: 2 students with unique birthdays already exist

  **AND**

- Event 2: a new student is added, also with a unique birthday

At this point, we can use the known theory on the probability of <a href="https://en.wikipedia.org/wiki/Independence_(probability_theory)#For_events" target="_blank">independent events</a>:

> The probability that two independent events *1* and *2* occur at the same time is *P<sub>(1 AND 2)</sub>* = *P<sub>1</sub>* · *P<sub>2</sub>*

<div class="figure">

<img src="images/independent_events.png" alt="Venn diagram with the events of pre-existing students having unique birthdays (white area, probability *P&lt;sub&gt;1&lt;/sub&gt;*) and the incoming student also having a unique birthday (dark grey area, probability *P&lt;sub&gt;2&lt;/sub&gt;*). Their overlap is both occurring at the same time, with probability *P&lt;sub&gt;(1&amp;nbsp;AND&amp;nbsp;2)&lt;/sub&gt;&amp;nbsp;= P&lt;sub&gt;1&lt;/sub&gt;&amp;nbsp;·&amp;nbsp;P&lt;sub&gt;2&lt;/sub&gt;*." width="100%" />
<p class="caption">

<span id="fig:unnamed-chunk-5"></span>Figure 2: Venn diagram with the events of pre-existing students having unique birthdays (white area, probability *P<sub>1</sub>*) and the incoming student also having a unique birthday (dark grey area, probability *P<sub>2</sub>*). Their overlap is both occurring at the same time, with probability *P<sub>(1 AND 2)</sub> = P<sub>1</sub> · P<sub>2</sub>*.
</p>

</div>

The available birthdays for this added student are **365‑2** out of 365, because it must be different from the 2 existing ones.

So the probability no common birthday at all is:
`$$\displaylines{P_{no~common~birthday,3} = P_{no~common~birthday,2} \cdot \frac{365-2}{365} \approx \\\ 0.9973 \cdot 0.9945 = 0.9918}$$`

Again, we can crosscheck with the precise *P<sub>common birthday,3</sub>* we calculated in part 1 (0.0082).
`$$P_{common~birthday,3} = 1 - P_{no~common~birthday,3} \approx 1 - 0.9918 = 0.0082$$`

It also matches, which means we’re on the right track.

### Any number of students

At this point, it’s important to spot the **pattern**. *P<sub>no common birthday,n</sub>* is based on *P<sub>no common birthday,n‑1</sub>*. For example:
`$$P_{no~common~birthday,\color{white}\colorbox{green}{3}} = P_{no~common~birthday,\color{white}\colorbox{purple}{2}} \cdot \frac{365 - \color{white}\colorbox{purple}{2}}{365}$$`

This has no reason to stop for any *n*:
`$$\bbox[5px, border: 3px solid currentColor]{P_{no~common~birthday,\color{white}\colorbox{green}{n}} = P_{no~common~birthday,\color{white}\colorbox{purple}{n – 1}} \cdot \frac{365 - \color{white}\colorbox{purple}{(n – 1)}}{365}}$$`

It’s easier to understand this formula exactly as we built it: by adding students one by one.

<div class="figure">

<img src="images/calculation1.gif" alt="Probability of *no common birthday* in a classroom. Top right pie chart: amount of days in the year that are 'available' or 'taken' by existing students. Illustration inspired by Wrath of Math's &lt;a href='https://www.youtube.com/watch?v=OcCRflNM-Xk' target='_blank'&gt;YouTube video&lt;/a&gt;." width="100%" />
<p class="caption">

<span id="fig:unnamed-chunk-6"></span>Figure 3: Probability of *no common birthday* in a classroom. Top right pie chart: amount of days in the year that are ‘available’ or ‘taken’ by existing students. Illustration inspired by Wrath of Math’s <a href='https://www.youtube.com/watch?v=OcCRflNM-Xk' target='_blank'>YouTube video</a>.
</p>

</div>

Two things come out of this:

1.  It vaguely makes sense why *P<sub>common birthday</sub>* quickly blows up: the probability of its opposite event quickly shrinks.

    *P<sub>no common birthday</sub>* starts from 1 (or 100%), but is multiplied with a smaller and smaller fraction with each added student, speeding towards 0.

2.  We just stumbled upon the concept of <span class="tooltip">mathematical recursion<span class="tooltiptext">Not to be confused with <a href="https://en.wikipedia.org/wiki/Recursion_(computer_science)" target="_blank">computational recursion</a>, which will not be used in this post.</span></span>: defining something in terms of a simpler version of itself.

    - The result for any number *n* is based on the result for the **previous number** (*n‑1*).
    - This goes all the way down to the **base case** of *n=1*: *P<sub>no common birthday,1</sub> = 1*.

## **Programming:** step-by-step calculation of *P<sub>no common birthday</sub>*

Now that we have a recursive formula for *P<sub>no common birthday</sub>*, we need to encode it for the computer to calculate and give it back to us nicely organized.

For each *n*, *P<sub>no common birthday</sub>* is essentially all the probabilities *P<sub>new unique birthday</sub>* **up to that *n***, multiplied together. In other words:

> *P<sub>no common birthday</sub>* is the **cumulative product** of *P<sub>new unique birthday</sub>*.

<div class="figure">

<img src="images/calculation2.gif" alt="Approach to calculating *P&lt;sub&gt;no&amp;nbsp;common&amp;nbsp;birthday&lt;/sub&gt;* as the cumulative product of *P&lt;sub&gt;new&amp;nbsp;unique&amp;nbsp;birthday&lt;/sub&gt;* (merging green boxes: multiplication)." width="100%" />
<p class="caption">

<span id="fig:unnamed-chunk-7"></span>Figure 4: Approach to calculating *P<sub>no common birthday</sub>* as the cumulative product of *P<sub>new unique birthday</sub>* (merging green boxes: multiplication).
</p>

</div>

Let’s initiate a data structure similar to figure 4. The code below creates a data table to calculate the probability for **up to 50 students**.

``` r
library(data.table)

# Initiate a data table with one column for the number of students (n)
common.birthday.prob.data <- data.table(n=1:50)

# Calculate the pool of available birthdays for the latest added student
common.birthday.prob.data[,available.birthdays := 365-(n-1)]

# Calculate the probability that the latest added student's birthday is unique
common.birthday.prob.data[,P.new.unique := available.birthdays/365]

# Display the data table
common.birthday.prob.data
```

    ##      n available.birthdays P.new.unique
    ##  1:  1                 365    1.0000000
    ##  2:  2                 364    0.9972603
    ##  3:  3                 363    0.9945205
    ##  4:  4                 362    0.9917808
    ##  5:  5                 361    0.9890411
    ## ---                                    
    ## 46: 46                 320    0.8767123
    ## 47: 47                 319    0.8739726
    ## 48: 48                 318    0.8712329
    ## 49: 49                 317    0.8684932
    ## 50: 50                 316    0.8657534

<details>

<summary>

Code explanation
</summary>

We create a [data table](/coding/data-tables/) named `common.birthday.prob.data`, using the R package `data.table`.

The table initially has just one column for the number of students (`n`), from 1 to 50 (see [Sequences](/coding/sequences/#when-the-increment-is-1) for details).

We [create new columns](/coding/column-operations/#creating-new-columns) one by one:

- `available.birthdays`: the number of available birthdays for the latest added student to have a unique birthday. Calculated as `\(365-(n-1).\)`

- `P.new.unique`: *P<sub>new unique birthday</sub>*, in other words the probability of the latest added student to have a unique birthday. Calculated as `\(\frac{available~birthdays}{365}.\)`

</details>

The resulting data table is very similar to the one in figure 4, except it is vertical instead of horizontal.

The code below calculates *P<sub>no common birthday</sub>* as the cumulative product of *P<sub>new unique birthday</sub>*.

``` r
# Calculate the probability of no common birthday
common.birthday.prob.data[,P.no.common.birthday := cumprod(P.new.unique)]

common.birthday.prob.data
```

    ##      n available.birthdays P.new.unique P.no.common.birthday
    ##  1:  1                 365    1.0000000           1.00000000
    ##  2:  2                 364    0.9972603           0.99726027
    ##  3:  3                 363    0.9945205           0.99179583
    ##  4:  4                 362    0.9917808           0.98364409
    ##  5:  5                 361    0.9890411           0.97286443
    ## ---                                                         
    ## 46: 46                 320    0.8767123           0.05174716
    ## 47: 47                 319    0.8739726           0.04522560
    ## 48: 48                 318    0.8712329           0.03940203
    ## 49: 49                 317    0.8684932           0.03422039
    ## 50: 50                 316    0.8657534           0.02962642

<details>

<summary>

Code explanation
</summary>

We create a new column `P.no.common.birthday` and assign it the resulting *P<sub>no common birthday</sub>*.

This new column is calculated with the `cumprod` [function](/coding/functions/) on column `P.new.unique`.

`cumprod` calculates the **cumulative product** of a [vector](/coding/vectors/):

<div class="figure">

<img src="images/cumprod.gif" alt="The `cumprod` function calculates the cumulative product of a vector `x` with elements *x&lt;sub&gt;1&lt;/sub&gt;*, *x&lt;sub&gt;2&lt;/sub&gt;*, ..., *x&lt;sub&gt;n&lt;/sub&gt;* (merging green boxes: multiplication)." width="100%" />
<p class="caption">

<span id="fig:unnamed-chunk-10"></span>Figure 5: The `cumprod` function calculates the cumulative product of a vector `x` with elements *x<sub>1</sub>*, *x<sub>2</sub>*, …, *x<sub>n</sub>* (merging green boxes: multiplication).
</p>

</div>

</details>

The final step is to simply calculate *P<sub>common birthday</sub>* = 1 - *P<sub>no common birthday</sub>* for each classroom size:

``` r
# Calculate the probability of at least one common birthday
common.birthday.prob.data[,P.common.birthday := 1 - P.no.common.birthday]

common.birthday.prob.data
```

    ##      n available.birthdays P.new.unique P.no.common.birthday P.common.birthday
    ##  1:  1                 365    1.0000000           1.00000000       0.000000000
    ##  2:  2                 364    0.9972603           0.99726027       0.002739726
    ##  3:  3                 363    0.9945205           0.99179583       0.008204166
    ##  4:  4                 362    0.9917808           0.98364409       0.016355912
    ##  5:  5                 361    0.9890411           0.97286443       0.027135574
    ## ---                                                                           
    ## 46: 46                 320    0.8767123           0.05174716       0.948252843
    ## 47: 47                 319    0.8739726           0.04522560       0.954774403
    ## 48: 48                 318    0.8712329           0.03940203       0.960597973
    ## 49: 49                 317    0.8684932           0.03422039       0.965779609
    ## 50: 50                 316    0.8657534           0.02962642       0.970373580

<details>

<summary>

Code explanation
</summary>

We create a new column `P.common.birthday` with the calculated *P<sub>common birthday</sub>* for each classroom size.

</details>

We made it. The column `P.common.birthday` is the calculated *P<sub>common birthday</sub>* that we initially set out to find.

## **Results:** Probability *vs* sampling frequency

We can now see how closely we approximated the **true** *P<sub>common birthday</sub>* in [part 2](/posts/birthday-problem-2/). The plot below compares the precise probabilities we just found with the sampling frequencies from part 2:

<div class="figure">

<div class="plotly html-widget html-fill-item" id="htmlwidget-1" style="width:100%;height:480px;"></div>
<script type="application/json" data-for="htmlwidget-1">{"x":{"data":[{"x":[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50],"y":[0,0.002739726027397249,0.0082041658847813448,0.016355912466550215,0.027135573699793469,0.040462483649111425,0.056235703095975365,0.074335292351669024,0.094623833889166731,0.11694817771107768,0.14114137832173312,0.16702478883806438,0.19441027523242937,0.223102512004973,0.25290131976368635,0.2836040052528499,0.31500766529656066,0.34691141787178936,0.37911852603153673,0.41143838358058005,0.44368833516520578,0.47569530766255008,0.50729723432398544,0.53834425791452878,0.5686997039694639,0.59824082013593904,0.62685928226324195,0.65446147234239938,0.68096853747777697,0.70631624271926863,0.73045463372864394,0.75334752785032066,0.77497185417577197,0.79531686462015427,0.8143832388747152,0.83218210637987955,0.84873400821638456,0.86406782108212088,0.87821966436672205,0.89123180981794903,0.90315161148173539,0.91403047156186923,0.92392285565611987,0.93288536855142634,0.94097589946577487,0.94825284336725468,0.9547744028332994,0.96059797287942239,0.96577960932267648,0.97037357957798842],"text":["Classroom size n: 1<br />Probability: 0","Classroom size n: 2<br />Probability: 0.0027","Classroom size n: 3<br />Probability: 0.0082","Classroom size n: 4<br />Probability: 0.0164","Classroom size n: 5<br />Probability: 0.0271","Classroom size n: 6<br />Probability: 0.0405","Classroom size n: 7<br />Probability: 0.0562","Classroom size n: 8<br />Probability: 0.0743","Classroom size n: 9<br />Probability: 0.0946","Classroom size n: 10<br />Probability: 0.1169","Classroom size n: 11<br />Probability: 0.1411","Classroom size n: 12<br />Probability: 0.167","Classroom size n: 13<br />Probability: 0.1944","Classroom size n: 14<br />Probability: 0.2231","Classroom size n: 15<br />Probability: 0.2529","Classroom size n: 16<br />Probability: 0.2836","Classroom size n: 17<br />Probability: 0.315","Classroom size n: 18<br />Probability: 0.3469","Classroom size n: 19<br />Probability: 0.3791","Classroom size n: 20<br />Probability: 0.4114","Classroom size n: 21<br />Probability: 0.4437","Classroom size n: 22<br />Probability: 0.4757","Classroom size n: 23<br />Probability: 0.5073","Classroom size n: 24<br />Probability: 0.5383","Classroom size n: 25<br />Probability: 0.5687","Classroom size n: 26<br />Probability: 0.5982","Classroom size n: 27<br />Probability: 0.6269","Classroom size n: 28<br />Probability: 0.6545","Classroom size n: 29<br />Probability: 0.681","Classroom size n: 30<br />Probability: 0.7063","Classroom size n: 31<br />Probability: 0.7305","Classroom size n: 32<br />Probability: 0.7533","Classroom size n: 33<br />Probability: 0.775","Classroom size n: 34<br />Probability: 0.7953","Classroom size n: 35<br />Probability: 0.8144","Classroom size n: 36<br />Probability: 0.8322","Classroom size n: 37<br />Probability: 0.8487","Classroom size n: 38<br />Probability: 0.8641","Classroom size n: 39<br />Probability: 0.8782","Classroom size n: 40<br />Probability: 0.8912","Classroom size n: 41<br />Probability: 0.9032","Classroom size n: 42<br />Probability: 0.914","Classroom size n: 43<br />Probability: 0.9239","Classroom size n: 44<br />Probability: 0.9329","Classroom size n: 45<br />Probability: 0.941","Classroom size n: 46<br />Probability: 0.9483","Classroom size n: 47<br />Probability: 0.9548","Classroom size n: 48<br />Probability: 0.9606","Classroom size n: 49<br />Probability: 0.9658","Classroom size n: 50<br />Probability: 0.9704"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(0,0,0,1)","opacity":1,"size":6.4251968503937009,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(0,0,0,1)"}},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"orientation":"v","width":[0.90000000000000013,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.89999999999999947,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.90000000000000213,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568],"base":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"x":[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50],"y":[0.0044999999999999997,0.0060000000000000001,0.0155,0.029999999999999999,0.044999999999999998,0.061499999999999999,0.070999999999999994,0.097500000000000003,0.1225,0.13250000000000001,0.158,0.1875,0.22650000000000001,0.252,0.27100000000000002,0.3125,0.36299999999999999,0.39550000000000002,0.41799999999999998,0.44550000000000001,0.46999999999999997,0.50149999999999995,0.52549999999999997,0.5665,0.59650000000000003,0.629,0.65549999999999997,0.67300000000000004,0.71450000000000002,0.72950000000000004,0.76200000000000001,0.76700000000000002,0.79749999999999999,0.82250000000000001,0.82850000000000001,0.84099999999999997,0.85599999999999998,0.88149999999999995,0.89100000000000001,0.90000000000000002,0.91400000000000003,0.91849999999999998,0.94399999999999995,0.94099999999999995,0.93999999999999995,0.95899999999999996,0.96599999999999997,0.95899999999999996,0.96599999999999997],"text":["Classroom size n: 2<br />Frequency: 0.0045","Classroom size n: 3<br />Frequency: 0.006","Classroom size n: 4<br />Frequency: 0.0155","Classroom size n: 5<br />Frequency: 0.03","Classroom size n: 6<br />Frequency: 0.045","Classroom size n: 7<br />Frequency: 0.0615","Classroom size n: 8<br />Frequency: 0.071","Classroom size n: 9<br />Frequency: 0.0975","Classroom size n: 10<br />Frequency: 0.1225","Classroom size n: 11<br />Frequency: 0.1325","Classroom size n: 12<br />Frequency: 0.158","Classroom size n: 13<br />Frequency: 0.1875","Classroom size n: 14<br />Frequency: 0.2265","Classroom size n: 15<br />Frequency: 0.252","Classroom size n: 16<br />Frequency: 0.271","Classroom size n: 17<br />Frequency: 0.3125","Classroom size n: 18<br />Frequency: 0.363","Classroom size n: 19<br />Frequency: 0.3955","Classroom size n: 20<br />Frequency: 0.418","Classroom size n: 21<br />Frequency: 0.4455","Classroom size n: 22<br />Frequency: 0.47","Classroom size n: 23<br />Frequency: 0.5015","Classroom size n: 24<br />Frequency: 0.5255","Classroom size n: 25<br />Frequency: 0.5665","Classroom size n: 26<br />Frequency: 0.5965","Classroom size n: 27<br />Frequency: 0.629","Classroom size n: 28<br />Frequency: 0.6555","Classroom size n: 29<br />Frequency: 0.673","Classroom size n: 30<br />Frequency: 0.7145","Classroom size n: 31<br />Frequency: 0.7295","Classroom size n: 32<br />Frequency: 0.762","Classroom size n: 33<br />Frequency: 0.767","Classroom size n: 34<br />Frequency: 0.7975","Classroom size n: 35<br />Frequency: 0.8225","Classroom size n: 36<br />Frequency: 0.8285","Classroom size n: 37<br />Frequency: 0.841","Classroom size n: 38<br />Frequency: 0.856","Classroom size n: 39<br />Frequency: 0.8815","Classroom size n: 40<br />Frequency: 0.891","Classroom size n: 41<br />Frequency: 0.9","Classroom size n: 42<br />Frequency: 0.914","Classroom size n: 43<br />Frequency: 0.9185","Classroom size n: 44<br />Frequency: 0.944","Classroom size n: 45<br />Frequency: 0.941","Classroom size n: 46<br />Frequency: 0.94","Classroom size n: 47<br />Frequency: 0.959","Classroom size n: 48<br />Frequency: 0.966","Classroom size n: 49<br />Frequency: 0.959","Classroom size n: 50<br />Frequency: 0.966"],"type":"bar","textposition":"none","marker":{"autocolorscale":false,"color":"rgba(89,89,89,1)","line":{"width":1.8897637795275593,"color":"transparent"}},"showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null}],"layout":{"margin":{"t":23.305936073059364,"r":7.3059360730593621,"b":45.496056454960566,"l":61.436280614362801},"plot_bgcolor":"rgba(216,216,216,1)","paper_bgcolor":"rgba(216,216,216,1)","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"xaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[0.59999999999999998,50.850000000000001],"tickmode":"array","ticktext":["10","20","30","40","50"],"tickvals":[10,20,29.999999999999996,40,50],"categoryorder":"array","categoryarray":["10","20","30","40","50"],"nticks":null,"ticks":"outside","tickcolor":"rgba(0,0,0,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(0,0,0,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"y","title":{"text":"Classroom size n (students)","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"yaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[-0.01,1.01],"tickmode":"array","ticktext":["0.00","0.25","0.50","0.75","1.00"],"tickvals":[0,0.25,0.5,0.75,1],"categoryorder":"array","categoryarray":["0.00","0.25","0.50","0.75","1.00"],"nticks":null,"ticks":"outside","tickcolor":"rgba(0,0,0,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(0,0,0,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"x","title":{"text":"Probability / Sampling frequency","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"shapes":[],"showlegend":false,"legend":{"bgcolor":"rgba(255,255,255,1)","bordercolor":"transparent","borderwidth":1.8897637795275593,"font":{"color":"rgba(0,0,0,1)","family":"","size":11.68949771689498}},"hovermode":"closest","barmode":"relative"},"config":{"doubleClick":"reset","modeBarButtonsToAdd":["hoverclosest","hovercompare"],"showSendToCloud":false},"source":"A","attrs":{"c5141362318f":{"x":{},"y":{},"text":{},"type":"scatter"},"c514779c6c6c":{"x":{},"y":{},"text":{}}},"cur_data":"c5141362318f","visdat":{"c5141362318f":["function (y) ","x"],"c514779c6c6c":["function (y) ","x"]},"highlight":{"on":"plotly_click","persistent":false,"dynamic":false,"selectize":false,"opacityDim":0.20000000000000001,"selected":{"opacity":1},"debounce":0},"shinyEvents":["plotly_hover","plotly_click","plotly_selected","plotly_relayout","plotly_brushed","plotly_brushing","plotly_clickannotation","plotly_doubleclick","plotly_deselect","plotly_afterplot","plotly_sunburstclick"],"base_url":"https://plot.ly"},"evals":[],"jsHooks":[]}</script>

<p class="caption">

<span id="fig:unnamed-chunk-12"></span>Figure 6: Probability (black points) and sampling frequency (grey bars) of at least one common birthday, for different classroom sizes. Sampling frequencies taken from [part 2](/posts/birthday-problem-2/). Hover cursor over data points and bars for details.
</p>

</div>

So the approximate solutions from part 2 are extremely close to the real probabilities. It seems Monte Carlo sampling was a good enough method to reproduce the pattern.

## The problem solving triangle

With a series of three full blog posts, I’ve given an unreasonable amount of thought to this brain teaser. The overarching point I want to make is:

> **There are different ways to approach the same problem.**

And not just vaguely different. The different approaches in this series follow a specific framework.

“*Good, fast, cheap. Choose two.*” concisely expresses the *triple constraint* or *<a href="https://en.wikipedia.org/wiki/Project_management_triangle" target="_blank">project management triangle</a>*: a model of common constraints in project management: **scope**, **time**, and **cost**.

Looking back on this series, I see a slight variation of this in problem solving. The *spectrum* of different approaches is roughly shaped by constraints on three factors:

- **scope**, meaning what we actually get
- **time** and effort spent
- available **resources**

The figure below shows how these factors played into each of the three parts in this series. Toggle between parts 1, 2, and 3.

<div>

<span style="white-space: nowrap;">
<input type="radio" name="constraints-blog-part" id="1" value="1" checked/>
<label for="1">Part 1: Counting</label>
</span>
<span style="white-space: nowrap;">
<input type="radio" name="constraints-blog-part" id="2" value="2"/>
<label for="2">Part 2: Monte Carlo sampling</label>
</span>
<span style="white-space: nowrap;">
<input type="radio" name="constraints-blog-part" id="3" value="3"/>
<label for="3">Part 3: Analytical solution</label>
</span>

</div>

<div class="figure">

<img src="images/constraints-1.png" alt="Severity of constraints of our three different approaches on the birthday problem. Light color: limited or high-demand factor; dark color: abundant or low-demand factor." width="90%" id='img-constraints' />
<p class="caption">

<span id="fig:unnamed-chunk-13"></span>Figure 7: Severity of constraints of our three different approaches on the birthday problem. Light color: limited or high-demand factor; dark color: abundant or low-demand factor.
</p>

</div>

<script src="scripts/radio_buttons.js"></script>

In this case, we can choose approach depending on our needs and resources:

- **Counting**: we’re satisfied with an extremely narrow scope or have much, **much** more computational resources.

- **Monte Carlo sampling**: we care about being *more or less* correct and can’t -or don’t care to- approach the problem analytically. Monte Carlo sampling is commonly used for difficult or impossible problems to solve analytically.

- **Analytical solution**: we want precision and have enough understanding for an analytical approach.

Sometimes perfect is the enemy of good, and cutting corners is necessary to get to **a** solution. Other times we need **the** best or most precise solution, and can afford the cost and effort it takes to get there.

No right or wrong. Just scope, time, and resources.

<details>

<summary>

Session info
</summary>

    ## R version 4.6.0 (2026-04-24 ucrt)
    ## Platform: x86_64-w64-mingw32/x64
    ## Running under: Windows 11 x64 (build 26200)
    ## 
    ## Matrix products: default
    ##   LAPACK version 3.12.1
    ## 
    ## locale:
    ## [1] LC_COLLATE=English_United States.utf8 
    ## [2] LC_CTYPE=English_United States.utf8   
    ## [3] LC_MONETARY=English_United States.utf8
    ## [4] LC_NUMERIC=C                          
    ## [5] LC_TIME=English_United States.utf8    
    ## 
    ## time zone: Europe/Stockholm
    ## tzcode source: internal
    ## 
    ## attached base packages:
    ## [1] stats     graphics  grDevices utils     datasets  methods   base     
    ## 
    ## other attached packages:
    ## [1] plotly_4.12.0     ggthemes_5.2.0    ggplot2_4.0.3     data.table_1.18.4
    ## [5] blogdown_1.23    
    ## 
    ## loaded via a namespace (and not attached):
    ##  [1] gtable_0.3.6       jsonlite_2.0.0     dplyr_1.2.1        compiler_4.6.0    
    ##  [5] tidyselect_1.2.1   stringr_1.6.0      tidyr_1.3.2        jquerylib_0.1.4   
    ##  [9] scales_1.4.0       yaml_2.3.12        fastmap_1.2.0      R6_2.6.1          
    ## [13] labeling_0.4.3     generics_0.1.4     knitr_1.51         htmlwidgets_1.6.4 
    ## [17] tibble_3.3.1       bookdown_0.46      bslib_0.11.0       pillar_1.11.1     
    ## [21] RColorBrewer_1.1-3 rlang_1.2.0        cachem_1.1.0       stringi_1.8.7     
    ## [25] xfun_0.57          sass_0.4.10        S7_0.2.2           lazyeval_0.2.3    
    ## [29] otel_0.2.0         viridisLite_0.4.3  cli_3.6.6          withr_3.0.2       
    ## [33] magrittr_2.0.5     crosstalk_1.2.2    digest_0.6.39      grid_4.6.0        
    ## [37] rstudioapi_0.18.0  lifecycle_1.0.5    vctrs_0.7.3        evaluate_1.0.5    
    ## [41] glue_1.8.1         farver_2.1.2       httr_1.4.8         rmarkdown_2.31    
    ## [45] purrr_1.2.2        tools_4.6.0        pkgconfig_2.0.3    htmltools_0.5.9

</details>
