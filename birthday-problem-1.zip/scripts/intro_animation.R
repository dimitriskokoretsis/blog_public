rotation_direction <- function(a,b) {
  forward <- (b - a) %% (2*pi)
  backward <- - ((a - b - 2*pi) %% (2*pi))
  shortest <- pmin(abs(forward),abs(backward))
  shortest <- fifelse(abs(shortest)==forward,
                      shortest,
                      -shortest)
  return(shortest)
}

# Create birthday data for animation
iterations <- 4
students <- 5
anim.frames <- 20

library(data.table)
d <- CJ(classroom=seq_len(iterations),student.index=seq_len(students),color="red")
set.seed(6)
d[,birthday:=sample(x=1:365,size=iterations,replace=FALSE),by=student.index]
d[classroom==iterations & (student.index %in% c(students-1,students)),
  `:=`(color="green",birthday=290)]
d <- list(data.table(classroom=0,student.index=seq_len(students),color="red",birthday=365),
          d) |> rbindlist()
d[,radians:=(birthday*2*pi/365) %% (2*pi)]

if(!file.exists("images/intro_animation.gif")) {
  intro.animation <- magick::image_graph(width=400,height=400)
  
  # Make animation
  for(iteration in seq_len(iterations)) {
    rotation <- data.table(student.index=seq_len(students))
    rotation[,shortest:=rotation_direction(a=d[classroom==iteration-1,radians],
                                           b=d[classroom==iteration,radians])]
    
    anim.data <- lapply(
      X=seq_len(students),
      FUN=function(student,rotation,anim.frames,d,iteration) {
        return(
          data.table(student.index=student,
                     frame=seq_len(anim.frames),
                     radians=seq(from=d[classroom==iteration-1 & student.index==student,radians],
                                 to=d[classroom==iteration-1 & student.index==student,radians +
                                        rotation[student.index==student,shortest]],
                                 length.out=anim.frames)))
      },rotation=rotation,
      anim.frames=anim.frames,
      d=d,
      iteration=iteration
    ) |> rbindlist()
    
    anim.data[,color:="red"][
      frame==anim.frames,
      color:=fifelse(d[classroom==iteration,color=="green"],
                     "green",
                     color)
    ]
    
    anim.data[,`:=`(x.coord=cos(radians),
                    y.coord=sin(radians))]
    
    # Move from previous to current iteration
    for(i in c(seq_len(anim.frames),
               rep(anim.frames,times=60))) {
      par(pty="s",
          xaxt="n",yaxt="n",
          mar=c(0,0,0,0))
      plot(x=c(-1.3,1.3),y=c(-1.3,1.3),type="n")
      text(x=-0.8,y=1.2,labels=paste("Classroom",iteration),cex=2.5)
      # Draw a circle for the whole year
      plotrix::draw.circle(x=c(0,0),y=c(0,0),radius=c(0.9,1.1))
      segments(x0=-1.1,x1=1.1,y0=0,y1=0)
      segments(x0=0,x1=0,y0=-1.1,y1=1.1)
      text(x=-0.5,y=0.5,labels="winter",cex=1.5)
      text(x=0.5,y=0.5,labels="spring",cex=1.5)
      text(x=-0.5,y=-0.5,labels="autumn",cex=1.5)
      text(x=0.5,y=-0.5,labels="summer",cex=1.5)
      
      # Draw small circles for each birthday
      for(student in seq_len(students)) {
        for(j in seq_len(20)) {
          plotrix::draw.circle(x=anim.data[frame==i & student.index==student,x.coord],
                               y=anim.data[frame==i & student.index==student,y.coord],
                               border=NA,
                               col=fifelse(anim.data[frame==i & student.index==student,color=="red"],
                                           rgb(red=1,green=0,blue=0,alpha=(j/20)^2.5),
                                           rgb(red=0,green=1,blue=0,alpha=(j/20)^2.5)),
                               radius=0.1-(j-1)*(0.1/20))
        }
      }
    }
  }
  dev.off()
  
  intro.animation |>
    magick::image_border(color="black",geometry="1x1") |>
    magick::image_write_gif(path="images/intro_animation.gif",delay=1/30)
  
  magick::image_destroy(intro.animation)
}


if(!file.exists("thumbnail.png")) {
  png(filename="thumbnail.png",width=400,height=400)
  
  par(pty="s",
      xaxt="n",yaxt="n",
      mar=c(0,0,0,0))
  plot(x=c(-1.3,1.3),y=c(-1.3,1.3),type="n")
  # Draw a circle for the whole year
  plotrix::draw.circle(x=c(0,0),y=c(0,0),radius=c(0.9,1.1))
  segments(x0=-1.1,x1=1.1,y0=0,y1=0)
  segments(x0=0,x1=0,y0=-1.1,y1=1.1)
  text(x=-0.5,y=0.5,labels="winter",cex=1.5)
  text(x=0.5,y=0.5,labels="spring",cex=1.5)
  text(x=-0.5,y=-0.5,labels="autumn",cex=1.5)
  text(x=0.5,y=-0.5,labels="summer",cex=1.5)
  
  # Draw small circles for each birthday
  for(student in seq_len(students)) {
    for(j in seq_len(20)) {
      plotrix::draw.circle(x=d[classroom==4 & student.index==student,cos(radians)],
                           y=d[classroom==4 & student.index==student,sin(radians)],
                           border=NA,
                           col=fifelse(d[classroom==4 & student.index==student,color=="red"],
                                       rgb(red=1,green=0,blue=0,alpha=(j/20)^2.5),
                                       rgb(red=0,green=1,blue=0,alpha=(j/20)^2.5)),
                           radius=0.1-(j-1)*(0.1/20))
    }
  }
  
  dev.off()
}
