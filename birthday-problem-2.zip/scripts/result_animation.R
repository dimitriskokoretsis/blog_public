set.seed(1)

common.classroom.birthdays[
  ,cumulative.frequency := cumsum(common.birthday)/classroom.index,
  by=classroom.size
][
  ,plotted := Rlab::rbern(n=1,prob=1/(classroom.index^(1/1.3))),
  by=classroom.index
]


library(gganimate)

tracking.plot <- common.classroom.birthdays[plotted==1 | classroom.index==sample.classrooms] |>
  ggplot(mapping=aes(x=classroom.size,y=cumulative.frequency)) +
  theme_classic() +
  theme(panel.background=element_rect(fill="#D8D8D8"),
        plot.background=element_rect(fill="#D8D8D8",color="black"),
        title=element_text(size=11.5),
        plot.title.position="plot",
        axis.title=element_text(size=11),
        axis.text=element_text(size=10)) +
  labs(title="Existence of a common birthday in a classroom",x="Classroom size (students)",y="Probability") +
  scale_x_continuous(expand=c(0,0)) +
  scale_y_continuous(limits=c(0,1.05),expand=c(0,0),labels=label_percent()) +
  geom_col() +
  #geom_hline(yintercept=0.5,linetype="dashed",linewidth=0.8) +
  geom_text(mapping=aes(label=paste("Sample:",classroom.index,"random classrooms"),
                        x=2,y=1.05,hjust=0,vjust=1),size=4,check_overlap=TRUE) +
  transition_states(states=classroom.index,transition_length=0.1,state_length=0,wrap=FALSE)

tracking.plot |>
  animate(duration=7,fps=20,renderer=gifski_renderer(),end_pause=40,width=800,height=600,units="px") |>
  anim_save(filename="thumbnail.gif",animation=_)