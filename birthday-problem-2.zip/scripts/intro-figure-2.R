library(magick)

figure.2.1 <- image_read(path="images/birthday-problem-2-2-1.png")
figure.2.2 <- image_read(path="images/birthday-problem-2-2-2.png")

figure.2.1.partial <- seq(from=1,to=0.01,by=-0.03) |>
  lapply(FUN=function(part,frame) {
    frame.width <- image_info(frame)$width[1]
    frame.height <- image_info(frame)$height[1]
    partial.frame <- frame |>
      image_crop(geometry=paste0(frame.width,"x",frame.height*part),
                 gravity="South")
    return(partial.frame)
  },frame=figure.2.1) |> image_join()

figure.2.open <- image_composite(image=figure.2.2,composite_image=figure.2.1.partial)
figure.2.close <- image_composite(image=figure.2.2,composite_image=rev(figure.2.1.partial))

c(rep(figure.2.1,times=20),figure.2.open,
  rep(figure.2.2,times=30),figure.2.close) |>
  image_border(color="black",geometry="1x1") |>
  image_write_gif(path="images/birthday-problem-2-2.gif",delay=1/15)