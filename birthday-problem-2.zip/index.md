---
title: 'The birthday problem — Part 2: The statistical shortcut'
author: Dimitris Kokoretsis
date: '2025-01-13'
slug: birthday-problem-2
header:
  image: 'thumbnail.gif'
source_link: true
mathjax: true
tags:
  - birthday-problem
  - probability
  - simulation
  - r-programming
coderefs:
  - variables
  - vectors
  - data-tables
  - sequences
  - apply-function-over-vector-list
  - cross-join
  - row-operations
  - column-operations
  - random-samples
  - aggregate-tables
  - logical-expressions
  - functions
---

<link href="{{< blogdown/postref >}}index_files/htmltools-fill/fill.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/htmlwidgets/htmlwidgets.js"></script>

<script src="{{< blogdown/postref >}}index_files/plotly-binding/plotly.js"></script>

<script src="{{< blogdown/postref >}}index_files/typedarray/typedarray.min.js"></script>

<script src="{{< blogdown/postref >}}index_files/jquery/jquery.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/crosstalk/css/crosstalk.min.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/crosstalk/js/crosstalk.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/plotly-htmlwidgets-css/plotly-htmlwidgets.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/plotly-main/plotly-latest.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/htmltools-fill/fill.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/htmlwidgets/htmlwidgets.js"></script>

<script src="{{< blogdown/postref >}}index_files/plotly-binding/plotly.js"></script>

<script src="{{< blogdown/postref >}}index_files/typedarray/typedarray.min.js"></script>

<script src="{{< blogdown/postref >}}index_files/jquery/jquery.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/crosstalk/css/crosstalk.min.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/crosstalk/js/crosstalk.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/plotly-htmlwidgets-css/plotly-htmlwidgets.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/plotly-main/plotly-latest.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/htmltools-fill/fill.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/htmlwidgets/htmlwidgets.js"></script>

<script src="{{< blogdown/postref >}}index_files/plotly-binding/plotly.js"></script>

<script src="{{< blogdown/postref >}}index_files/typedarray/typedarray.min.js"></script>

<script src="{{< blogdown/postref >}}index_files/jquery/jquery.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/crosstalk/css/crosstalk.min.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/crosstalk/js/crosstalk.min.js"></script>

<link href="{{< blogdown/postref >}}index_files/plotly-htmlwidgets-css/plotly-htmlwidgets.css" rel="stylesheet" />
<script src="{{< blogdown/postref >}}index_files/plotly-main/plotly-latest.min.js"></script>

In this post, we will answer a question that we previously failed at:

> What is the probability that two students in a classroom share the same birthday?

This is described as a **paradox** because for a classroom of realistic size, the probability is surprisingly higher than intuitively expected.

[Previously](/posts/birthday-problem-1), we could **only** solve this for very small classrooms of 2 or 3 students. The reason? **Too much data.**

We will now get around this obstacle by the means of random sampling.

## Precision *vs* efficiency

Our previous approach was designed for absolute precision. Unnecessary precision, in fact. The **counting** method, as described below, needs amounts of data that make any PC just give up:

1.  For a given classroom size, reproduce **all possible combinations** of birthdays (amount: n).

2.  Check each combination and **count** the ones with at least one common birthday (amount: n<sub>common birthday</sub>).

3.  The probability is the percentage: `\(P_{common~birthday} = \frac{n_{common~birthday}}{n}\)`

This method didn’t scale well with increasing classroom size. The required data increased **exponentially**, one of the worst ways to scale.

With just 4 students we needed to reproduce 365<sup>4</sup> ≈ **17.7 billion** combinations of 4 students each — at which point, we just got an error message.

<?xml version="1.0" encoding="utf-8"?>
<table>
  <thead>
    <tr>
      <th style="width:14%" align="center">Classroom size</th>
      <th style="width:21%" align="center">Total combinations (n)</th>
      <th style="width:17%" align="center">Reproducible</th>
      <th align="center">Combinations with common birthday (n<sub>common birthday</sub>)</th>
      <th align="center">Probability of common birthday (P<sub>common birthday</sub>)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td align="center">2 students</td>
      <td align="left" style="padding-left:20px">365<sup>2</sup> ≈ 133&nbsp;k</td>
      <td align="center">
        <img src="images/tick-mark.png" width="27%" />
      </td>
      <td align="right" style="padding-right:30px">365</td>
      <td align="right" style="padding-right:30px">$\frac{365}{365^2}=$ $0.27\%$ </td>
    </tr>
    <tr>
      <td align="center">3 students</td>
      <td align="left" style="padding-left:20px">365<sup>3</sup> ≈ 48.6&nbsp;Μ</td>
      <td align="center">
        <img src="images/tick-mark.png" width="27%" />
      </td>
      <td align="right" style="padding-right:30px">398&nbsp;945</td>
      <td align="right" style="padding-right:30px">$\frac{398~945}{365^3}=$ $0.82\%$</td>
    </tr>
    <tr>
      <td align="center">4 students</td>
      <td align="left" style="padding-left:20px">365<sup>4</sup> ≈ 17.7&nbsp;Β</td>
      <td align="center">
        <img src="images/x-mark.png" width="27%" />
      </td>
      <td align="right" style="padding-right:30px">?</td>
      <td align="right" style="padding-right:30px">$\frac{?}{365^4}=$ $~~~~?~\%$</td>
    </tr>
    <tr>
      <td align="center">...</td>
      <td align="center">...</td>
      <td align="center">
        <img src="images/x-mark.png" width="27%" />
      </td>
      <td align="right" style="padding-right:30px">...</td>
      <td align="right" style="padding-right:30px">...</td>
    </tr>
  </tbody>
</table>

For more realistic classrooms of, say, 25 students we’d need 365<sup>25</sup> combinations of 25 students each, a number that I don’t even dare calculate.

As a result, we cannot know this probability for classrooms with more than 2 or 3 students.

<div class="figure">

<div class="plotly html-widget html-fill-item" id="htmlwidget-1" style="width:100%;height:480px;"></div>
<script type="application/json" data-for="htmlwidget-1">{"x":{"data":[{"orientation":"v","width":[0.90000000000000013,0.90000000000000036],"base":[0,0],"x":[2,3],"y":[0.0027000000000000001,0.0082000000000000007],"text":["Classroom size: 2<br />Common birthday probability: 0.27%","Classroom size: 3<br />Common birthday probability: 0.82%"],"type":"bar","textposition":"none","marker":{"autocolorscale":false,"color":"rgba(89,89,89,1)","line":{"width":1.8897637795275593,"color":"transparent"}},"showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null}],"layout":{"margin":{"t":26.228310502283104,"r":7.3059360730593621,"b":48.418430884184303,"l":61.436280614362801},"plot_bgcolor":"rgba(216,216,216,1)","paper_bgcolor":"rgba(216,216,216,1)","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"xaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[1.5,50.5],"tickmode":"array","ticktext":["10","20","30","40","50"],"tickvals":[10,20,30,40,50],"categoryorder":"array","categoryarray":["10","20","30","40","50"],"nticks":null,"ticks":"outside","tickcolor":"rgba(51,51,51,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"y","title":{"text":"Classroom size (students)","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"yaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[0,1],"tickmode":"array","ticktext":["0%","25%","50%","75%","100%"],"tickvals":[0,0.25,0.5,0.75,1],"categoryorder":"array","categoryarray":["0%","25%","50%","75%","100%"],"nticks":null,"ticks":"outside","tickcolor":"rgba(51,51,51,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"x","title":{"text":"Probability","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"shapes":[{"type":"rect","fillcolor":null,"line":{"color":null,"width":0,"linetype":[]},"yref":"paper","xref":"paper","x0":0,"x1":1,"y0":0,"y1":1}],"showlegend":false,"legend":{"bgcolor":"rgba(255,255,255,1)","bordercolor":"transparent","borderwidth":1.8897637795275593,"font":{"color":"rgba(0,0,0,1)","family":"","size":11.68949771689498}},"hovermode":"closest","barmode":"relative"},"config":{"doubleClick":"reset","modeBarButtonsToAdd":["hoverclosest","hovercompare"],"showSendToCloud":false,"displayModeBar":false},"source":"A","attrs":{"e507a6c414e":{"x":{},"y":{},"text":{},"type":"bar"}},"cur_data":"e507a6c414e","visdat":{"e507a6c414e":["function (y) ","x"]},"highlight":{"on":"plotly_click","persistent":false,"dynamic":false,"selectize":false,"opacityDim":0.20000000000000001,"selected":{"opacity":1},"debounce":0},"shinyEvents":["plotly_hover","plotly_click","plotly_selected","plotly_relayout","plotly_brushed","plotly_brushing","plotly_clickannotation","plotly_doubleclick","plotly_deselect","plotly_afterplot","plotly_sunburstclick"],"base_url":"https://plot.ly"},"evals":[],"jsHooks":[]}</script>

<p class="caption">

<span id="fig:unnamed-chunk-3"></span>Figure 1: Probability that a classroom has at least one common birthday. Only showing known probabilities for 2- and 3-student classrooms.
</p>

</div>

## Strategy

To get around this for up to 50 students, we’ll **sacrifice precision for efficiency**: instead of reproducing all possible combinations, we’ll reproduce and analyze a much smaller random sample of them and get an **approximate** solution. Let’s go for 2 000 classrooms for each size.

<div class="figure">

<img src="images/birthday-problem-2-2.gif" alt="Strategy to find approximate solutions by random sampling." width="100%" />
<p class="caption">

<span id="fig:unnamed-chunk-5"></span>Figure 2: Strategy to find approximate solutions by random sampling.
</p>

</div>

Let’s start by defining these parameters:

``` r
max.classroom.size <- 50
sample.classrooms <- 2000
```

<details>

<summary>

Code explanation
</summary>

We assign the following parameters as [variables](/coding/variables/):

- `max.classroom.size` (50 students): the maximum classroom size (the minimum will be of course 2 students).

- `sample.classrooms` (2 000 random classrooms): the number of random classrooms to recreate for each size.

</details>

## Create data

We can now start creating our data. The code below recreates 2 000 classrooms of each size, ranging from 2 to 50 students.

``` r
library(data.table)

classroom.birthdays.sample <- 2:max.classroom.size |>
  
  lapply(FUN = function(classroom.size,sample.classrooms) {
    temp.data <- CJ(classroom.size = classroom.size,
                    classroom.index = 1:sample.classrooms,
                    student.index = 1:classroom.size)
    return(temp.data)
    }, sample.classrooms = sample.classrooms) |>
  
  rbindlist()
```

<details>

<summary>

Code explanation
</summary>

Our starting point is the [sequence](/coding/sequences/#when-the-increment-is-1) \[2, 3,…, 50\] (`2:max.classroom.size`), in other words all the classroom sizes we want to work with.

This sequence is passed to [`lapply`](/coding/apply-function-over-vector-list/) with the [pipe operator](/coding/functions/#nested-and-piped-function-calls) (`|>`). `lapply` creates a data table with 2 000 classrooms for each size, based on a custom function (see more details below).

The resulting data tables for different sizes are passed to `rbindlist`, which binds them together into one table for further analysis.

Details on the [custom function](/coding/functions/#creating-functions) `FUN`, which recreates classrooms of a specified size.

- It takes 2 arguments as input:

  - The 1<sup>st</sup> argument `classroom.size` represents each element of `2:max.classroom.size` inside the function. It changes between iterations, starting from 2 up to 50.

  - The 2<sup>nd</sup> argument `sample.classrooms` has one constant value (2 000). It is defined **after** the curly brackets and does not change between iterations.

- The data for each classroom size is constructed as `temp.data`:

  - `CJ` produces a cross-join table of given [vectors](/coding/vectors/), i.e. a [data table](/coding/data-tables/) with *all* combinations of each vector value (see [Cross-join](/coding/cross-join/) for more information). In this case, we produce a cross-join of 3 vectors:

    1.  `classroom.index`: sequence \[1, 2, …, 2 000\] (see [Sequences](/coding/sequences/#when-the-increment-is-1))

    2.  `student.index`: sequence \[1, 2, …, `classroom.size`\]

    3.  `classroom.size`: self-explanatory, 1 value in each iteration of `FUN`. It has just 1 value, so it creates a column without affecting the number of rows in the table.

- The resulting `temp.data` for each classroom size is **returned** as a result with the `return` command.

</details>

In the table we just created, each row represents a **single student** (`student.index`) who belongs to a specific classroom (`classroom.index`) of specific size (`classroom.size`).

Let’s take a look at the table:

``` r
classroom.birthdays.sample
```

    ##          classroom.size classroom.index student.index
    ##       1:              2               1             1
    ##       2:              2               1             2
    ##       3:              2               2             1
    ##       4:              2               2             2
    ##       5:              2               3             1
    ##      ---                                             
    ## 2547996:             50            2000            46
    ## 2547997:             50            2000            47
    ## 2547998:             50            2000            48
    ## 2547999:             50            2000            49
    ## 2548000:             50            2000            50

Next, we’re going to create a new column with a random birthday for each student.

``` r
set.seed(seed=1)

classroom.birthdays.sample[
  ,birthday:=sample(x=seq(from=as.Date("2025-01-01"),
                          to=as.Date("2025-12-31"),
                          by=1),
                    size=.N,replace=TRUE)]

classroom.birthdays.sample
```

    ##          classroom.size classroom.index student.index   birthday
    ##       1:              2               1             1 2025-11-20
    ##       2:              2               1             2 2025-06-16
    ##       3:              2               2             1 2025-05-09
    ##       4:              2               2             2 2025-10-26
    ##       5:              2               3             1 2025-09-27
    ##      ---                                                        
    ## 2547996:             50            2000            46 2025-03-02
    ## 2547997:             50            2000            47 2025-02-05
    ## 2547998:             50            2000            48 2025-02-08
    ## 2547999:             50            2000            49 2025-09-18
    ## 2548000:             50            2000            50 2025-07-01

<details>

<summary>

Code explanation
</summary>

- The `set.seed` function is usually run in the beginning of any experiment with random data, to ensure reproducibility. See [Random samples](/coding/random-samples/#initialize-seed) for more information.

- The first argument inside a `data.table`’s brackets determines which rows to handle. If left blank (as in this case), *all* rows are handled. See [Row operations](/coding/row-operations/) for more information.

- We use the `:=` assignment operator to create a new column on our `data.table`. See [Column operations](/coding/column-operations/#creating-new-columns) for more information.

- The `sample` function draws random elements from a specified set. See [Random samples](/coding/random-samples/) for general information. This is how we use it in this case:

  - `x`: The source of random values - in this case a `Date` vector with all days in the year 2025 (first to last day of the year incremented by 1, see [Sequences](/coding/sequences/) for more information).

  - `size`: The number of drawn random values, in this case `.N`. `.N` is a special symbol in the context of `data.table`, which gives the number of rows. In this case, it gives all the rows of the `data.table`.

  - `replace`: determines if the random sample drawing is done *with replacement*. In this case, it only makes sense to draw with replacement. See [Random samples](/coding/random-samples/#replacement) for more information.

</details>

## Analyze data

We now have all the data we need. All we have to do is *look at it*.

The code below creates a new data table `common.classroom.birthdays` from the original one.

In the new table, each row will represent a **whole classroom**. Each classroom will be marked for the occurrence of common birthdays: `TRUE` if a common birthday occurs, `FALSE` if it doesn’t.

``` r
common.classroom.birthdays <-
  classroom.birthdays.sample[
    ,.(common.birthday = (length(unique(birthday)) < classroom.size)),
    by=.(classroom.size,classroom.index)]

common.classroom.birthdays
```

    ##        classroom.size classroom.index common.birthday
    ##     1:              2               1           FALSE
    ##     2:              2               2           FALSE
    ##     3:              2               3           FALSE
    ##     4:              2               4           FALSE
    ##     5:              2               5           FALSE
    ##    ---                                               
    ## 97996:             50            1996            TRUE
    ## 97997:             50            1997            TRUE
    ## 97998:             50            1998            TRUE
    ## 97999:             50            1999            TRUE
    ## 98000:             50            2000            TRUE

<details>

<summary>

Code explanation
</summary>

We create and display an [aggregate table](/coding/aggregate-tables/), which groups students together by classroom and checks if common birthdays exist. This new table has the field `common.birthday`, with the value `TRUE` if a common birthday exists, or `FALSE` if not.

- The grouping together of students is set with the `by` argument. Each classroom has a unique combination of `classroom.size` and `classroom.index`. Therefore grouping by both separates the students by classroom.

- The assessment of each classroom is done with the [logical expression](/coding/logical-expressions/) `length(unique(birthday)) < classroom.size`:

  `FALSE` -\> `length(unique(birthday)) == classroom.size` -\> all birthdays are **unique** -\> **No** common birthdays.

  `TRUE` -\> `length(unique(birthday)) < classroom.size` -\> unique birthdays are **fewer** than the classroom size -\> **At least one** common birthday.

</details>

The new table has a field named `common.birthday`, which takes values `TRUE` or `FALSE`. Each classroom is marked based on the condition we set (`length(unique(birthday)) < classroom.size`).

<a id="final-calc"></a>Finally, the code below counts the classrooms of interest (n<sub>common birthday</sub>) for each classroom size and calculates their percentage (*frequency*) within that size.

``` r
common.classroom.birthdays.counted <-
  common.classroom.birthdays[
    ,.(common.birthdays.freq = sum(common.birthday==TRUE)/.N),
    by=classroom.size]
```

<details>

<summary>

Code explanation
</summary>

We count all classrooms where a common birthday occurs (`sum(common.birthday==TRUE)`) and divide them by the total number of classrooms (`.N`).

The resulting aggregate table is given the name `common.classroom.birthdays.counted`.

- We create a field called `common.birthdays.freq`. This field sums all classrooms where a common birthday occurs (`common.birthday==TRUE`) and divides the sum by the total number of classrooms (`.N`).

- In this case, the `by` argument groups the data by classroom size (`by=classroom.size`). This way, we calculate the frequency of common birthdays (`common.birthdays.freq`) **for each** classroom size.

</details>

Let’s see how the results look:

<div class="figure">

<div class="plotly html-widget html-fill-item" id="htmlwidget-2" style="width:100%;height:480px;"></div>
<script type="application/json" data-for="htmlwidget-2">{"x":{"data":[{"orientation":"v","width":[0.90000000000000013,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.89999999999999947,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.90000000000000213,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568],"base":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"x":[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50],"y":[0.0044999999999999997,0.0060000000000000001,0.0155,0.029999999999999999,0.044999999999999998,0.061499999999999999,0.070999999999999994,0.097500000000000003,0.1225,0.13250000000000001,0.158,0.1875,0.22650000000000001,0.252,0.27100000000000002,0.3125,0.36299999999999999,0.39550000000000002,0.41799999999999998,0.44550000000000001,0.46999999999999997,0.50149999999999995,0.52549999999999997,0.5665,0.59650000000000003,0.629,0.65549999999999997,0.67300000000000004,0.71450000000000002,0.72950000000000004,0.76200000000000001,0.76700000000000002,0.79749999999999999,0.82250000000000001,0.82850000000000001,0.84099999999999997,0.85599999999999998,0.88149999999999995,0.89100000000000001,0.90000000000000002,0.91400000000000003,0.91849999999999998,0.94399999999999995,0.94099999999999995,0.93999999999999995,0.95899999999999996,0.96599999999999997,0.95899999999999996,0.96599999999999997],"text":["Classroom size: 2<br />Common birthday frequency: 0.45%","Classroom size: 3<br />Common birthday frequency: 0.6%","Classroom size: 4<br />Common birthday frequency: 1.55%","Classroom size: 5<br />Common birthday frequency: 3%","Classroom size: 6<br />Common birthday frequency: 4.5%","Classroom size: 7<br />Common birthday frequency: 6.15%","Classroom size: 8<br />Common birthday frequency: 7.1%","Classroom size: 9<br />Common birthday frequency: 9.75%","Classroom size: 10<br />Common birthday frequency: 12.25%","Classroom size: 11<br />Common birthday frequency: 13.25%","Classroom size: 12<br />Common birthday frequency: 15.8%","Classroom size: 13<br />Common birthday frequency: 18.75%","Classroom size: 14<br />Common birthday frequency: 22.65%","Classroom size: 15<br />Common birthday frequency: 25.2%","Classroom size: 16<br />Common birthday frequency: 27.1%","Classroom size: 17<br />Common birthday frequency: 31.25%","Classroom size: 18<br />Common birthday frequency: 36.3%","Classroom size: 19<br />Common birthday frequency: 39.55%","Classroom size: 20<br />Common birthday frequency: 41.8%","Classroom size: 21<br />Common birthday frequency: 44.55%","Classroom size: 22<br />Common birthday frequency: 47%","Classroom size: 23<br />Common birthday frequency: 50.15%","Classroom size: 24<br />Common birthday frequency: 52.55%","Classroom size: 25<br />Common birthday frequency: 56.65%","Classroom size: 26<br />Common birthday frequency: 59.65%","Classroom size: 27<br />Common birthday frequency: 62.9%","Classroom size: 28<br />Common birthday frequency: 65.55%","Classroom size: 29<br />Common birthday frequency: 67.3%","Classroom size: 30<br />Common birthday frequency: 71.45%","Classroom size: 31<br />Common birthday frequency: 72.95%","Classroom size: 32<br />Common birthday frequency: 76.2%","Classroom size: 33<br />Common birthday frequency: 76.7%","Classroom size: 34<br />Common birthday frequency: 79.75%","Classroom size: 35<br />Common birthday frequency: 82.25%","Classroom size: 36<br />Common birthday frequency: 82.85%","Classroom size: 37<br />Common birthday frequency: 84.1%","Classroom size: 38<br />Common birthday frequency: 85.6%","Classroom size: 39<br />Common birthday frequency: 88.15%","Classroom size: 40<br />Common birthday frequency: 89.1%","Classroom size: 41<br />Common birthday frequency: 90%","Classroom size: 42<br />Common birthday frequency: 91.4%","Classroom size: 43<br />Common birthday frequency: 91.85%","Classroom size: 44<br />Common birthday frequency: 94.4%","Classroom size: 45<br />Common birthday frequency: 94.1%","Classroom size: 46<br />Common birthday frequency: 94%","Classroom size: 47<br />Common birthday frequency: 95.9%","Classroom size: 48<br />Common birthday frequency: 96.6%","Classroom size: 49<br />Common birthday frequency: 95.9%","Classroom size: 50<br />Common birthday frequency: 96.6%"],"type":"bar","textposition":"none","marker":{"autocolorscale":false,"color":"rgba(89,89,89,1)","line":{"width":1.8897637795275593,"color":"transparent"}},"showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1.55,50.450000000000003],"y":[0.5,0.5],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(0,0,0,1)","dash":"dash"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null}],"layout":{"margin":{"t":26.228310502283104,"r":7.3059360730593621,"b":48.418430884184303,"l":61.436280614362801},"plot_bgcolor":"rgba(216,216,216,1)","paper_bgcolor":"rgba(216,216,216,1)","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"xaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[1.55,50.450000000000003],"tickmode":"array","ticktext":["10","20","30","40","50"],"tickvals":[10,20,30,40,50],"categoryorder":"array","categoryarray":["10","20","30","40","50"],"nticks":null,"ticks":"outside","tickcolor":"rgba(51,51,51,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"y","title":{"text":"Classroom size (students)","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"yaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[0,1],"tickmode":"array","ticktext":["0%","25%","50%","75%","100%"],"tickvals":[0,0.25,0.5,0.75,1],"categoryorder":"array","categoryarray":["0%","25%","50%","75%","100%"],"nticks":null,"ticks":"outside","tickcolor":"rgba(51,51,51,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"x","title":{"text":"Frequency","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"shapes":[{"type":"rect","fillcolor":null,"line":{"color":null,"width":0,"linetype":[]},"yref":"paper","xref":"paper","x0":0,"x1":1,"y0":0,"y1":1}],"showlegend":false,"legend":{"bgcolor":"rgba(255,255,255,1)","bordercolor":"transparent","borderwidth":1.8897637795275593,"font":{"color":"rgba(0,0,0,1)","family":"","size":11.68949771689498}},"hovermode":"closest","barmode":"relative"},"config":{"doubleClick":"reset","modeBarButtonsToAdd":["hoverclosest","hovercompare"],"showSendToCloud":false,"displayModeBar":false},"source":"A","attrs":{"e50373b6526":{"x":{},"y":{},"text":{},"type":"bar"},"e506d4e1047":{"yintercept":{}}},"cur_data":"e50373b6526","visdat":{"e50373b6526":["function (y) ","x"],"e506d4e1047":["function (y) ","x"]},"highlight":{"on":"plotly_click","persistent":false,"dynamic":false,"selectize":false,"opacityDim":0.20000000000000001,"selected":{"opacity":1},"debounce":0},"shinyEvents":["plotly_hover","plotly_click","plotly_selected","plotly_relayout","plotly_brushed","plotly_brushing","plotly_clickannotation","plotly_doubleclick","plotly_deselect","plotly_afterplot","plotly_sunburstclick"],"base_url":"https://plot.ly"},"evals":[],"jsHooks":[]}</script>

<p class="caption">

<span id="fig:unnamed-chunk-13"></span>Figure 3: Frequency of classrooms where there is at least one common birthday. Dashed horizontal line: 50%.
</p>

</div>

Some observations:

1.  The main result is obvious: just 23 students are more likely to have a common birthday than not to have one (over 50% probability). This goes even higher for larger classrooms.

2.  The results for 2- and 3-student classrooms are not exactly the same as found previously, exactly because we sacrificed precision for efficiency. So the resulting frequencies are **approximations** of the true probabilities.

3.  For the same reason, the results are a bit “noisy”: there is a trend, but it’s not perfectly smooth.

## *Any common birthday* vs *same as **my** birthday*

I think the reason this is considered a paradox is that most people interpret the question as a different one:

> What is the probability that a classmate has the same birthday as **me**?

The classrooms that satisfy this condition also satisfy the original condition — but not the other way around. In other words, this is a more **specific** condition. Because of this, the probability is indeed quite lower.

So let’s actually see how it looks like in our data set: we can simply take student \#1 as a reference and check for any other students with matching birthdays.

The code below examines each random classroom and creates a column with `TRUE` or `FALSE` values for this specific condition.

``` r
common.classroom.birthdays.specific <-
  classroom.birthdays.sample[
    ,.(common.birthday.specific = (birthday[1] %in% birthday[-1])),
    by=.(classroom.size,classroom.index)]

common.classroom.birthdays.specific
```

    ##        classroom.size classroom.index common.birthday.specific
    ##     1:              2               1                    FALSE
    ##     2:              2               2                    FALSE
    ##     3:              2               3                    FALSE
    ##     4:              2               4                    FALSE
    ##     5:              2               5                    FALSE
    ##    ---                                                        
    ## 97996:             50            1996                    FALSE
    ## 97997:             50            1997                     TRUE
    ## 97998:             50            1998                    FALSE
    ## 97999:             50            1999                    FALSE
    ## 98000:             50            2000                    FALSE

<details>

<summary>

Code explanation
</summary>

We create and display an aggregate table, much like `common.classroom.birthdays`, but with a different condition, `birthday[1] %in% birthday[-1]` (see [Vectors](/coding/vectors/#accessing-vector-elements) for more information):

- `FALSE` -\> `!(birthday[1] %in% birthday[-1])` -\> no other student has the same birthday as student \#1.

- `TRUE` -\> `birthday[1] %in% birthday[-1]` -\> there is a matching birthday with that of student \#1.

</details>

The new table has a new field named `common.birthday.specific`, which takes values `TRUE` or `FALSE`. Each classroom is now marked based on the condition we set (`birthday[1] %in% birthday[-1]`).

To compare with the previous condition, we can bring all data together in one place. The piece of code below brings the new column to the original `common.classroom.birthdays` table.

As we now have data on both conditions, we can calculate the frequency of classrooms where each condition occurs (`TRUE`):

``` r
common.classroom.birthdays.specific.counted <-
  common.classroom.birthdays.specific[
    ,.(common.birthday.specific.freq=sum(common.birthday.specific)/.N),
    by=classroom.size]

common.classroom.birthdays.specific.counted
```

    ##     classroom.size common.birthday.specific.freq
    ##  1:              2                        0.0045
    ##  2:              3                        0.0025
    ##  3:              4                        0.0050
    ##  4:              5                        0.0155
    ##  5:              6                        0.0170
    ## ---                                             
    ## 45:             46                        0.1200
    ## 46:             47                        0.1175
    ## 47:             48                        0.1165
    ## 48:             49                        0.1355
    ## 49:             50                        0.1175

<details>

<summary>

Code explanation
</summary>

The code is virtually identical with a [previous](#final-calc) code snippet — except it creates the field `common.birthday.specific.freq`, which calculates the frequency of classrooms that satisfy the more specific condition.

</details>

As expected, the more specific condition “common birthday with **me**” indeed seems to have lower probability than the original condition, especially for larger classrooms.

Let’s get a wider overview of how it compares to the original condition:

<div class="figure">

<div class="plotly html-widget html-fill-item" id="htmlwidget-3" style="width:100%;height:480px;"></div>
<script type="application/json" data-for="htmlwidget-3">{"x":{"data":[{"orientation":"v","width":[0.90000000000000013,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.89999999999999947,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.90000000000000213,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568],"base":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"x":[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50],"y":[0.0044999999999999997,0.0060000000000000001,0.0155,0.029999999999999999,0.044999999999999998,0.061499999999999999,0.070999999999999994,0.097500000000000003,0.1225,0.13250000000000001,0.158,0.1875,0.22650000000000001,0.252,0.27100000000000002,0.3125,0.36299999999999999,0.39550000000000002,0.41799999999999998,0.44550000000000001,0.46999999999999997,0.50149999999999995,0.52549999999999997,0.5665,0.59650000000000003,0.629,0.65549999999999997,0.67300000000000004,0.71450000000000002,0.72950000000000004,0.76200000000000001,0.76700000000000002,0.79749999999999999,0.82250000000000001,0.82850000000000001,0.84099999999999997,0.85599999999999998,0.88149999999999995,0.89100000000000001,0.90000000000000002,0.91400000000000003,0.91849999999999998,0.94399999999999995,0.94099999999999995,0.93999999999999995,0.95899999999999996,0.96599999999999997,0.95899999999999996,0.96599999999999997],"text":["Classroom size: 2<br />Common birthday frequency: 0.45%","Classroom size: 3<br />Common birthday frequency: 0.6%","Classroom size: 4<br />Common birthday frequency: 1.55%","Classroom size: 5<br />Common birthday frequency: 3%","Classroom size: 6<br />Common birthday frequency: 4.5%","Classroom size: 7<br />Common birthday frequency: 6.15%","Classroom size: 8<br />Common birthday frequency: 7.1%","Classroom size: 9<br />Common birthday frequency: 9.75%","Classroom size: 10<br />Common birthday frequency: 12.25%","Classroom size: 11<br />Common birthday frequency: 13.25%","Classroom size: 12<br />Common birthday frequency: 15.8%","Classroom size: 13<br />Common birthday frequency: 18.75%","Classroom size: 14<br />Common birthday frequency: 22.65%","Classroom size: 15<br />Common birthday frequency: 25.2%","Classroom size: 16<br />Common birthday frequency: 27.1%","Classroom size: 17<br />Common birthday frequency: 31.25%","Classroom size: 18<br />Common birthday frequency: 36.3%","Classroom size: 19<br />Common birthday frequency: 39.55%","Classroom size: 20<br />Common birthday frequency: 41.8%","Classroom size: 21<br />Common birthday frequency: 44.55%","Classroom size: 22<br />Common birthday frequency: 47%","Classroom size: 23<br />Common birthday frequency: 50.15%","Classroom size: 24<br />Common birthday frequency: 52.55%","Classroom size: 25<br />Common birthday frequency: 56.65%","Classroom size: 26<br />Common birthday frequency: 59.65%","Classroom size: 27<br />Common birthday frequency: 62.9%","Classroom size: 28<br />Common birthday frequency: 65.55%","Classroom size: 29<br />Common birthday frequency: 67.3%","Classroom size: 30<br />Common birthday frequency: 71.45%","Classroom size: 31<br />Common birthday frequency: 72.95%","Classroom size: 32<br />Common birthday frequency: 76.2%","Classroom size: 33<br />Common birthday frequency: 76.7%","Classroom size: 34<br />Common birthday frequency: 79.75%","Classroom size: 35<br />Common birthday frequency: 82.25%","Classroom size: 36<br />Common birthday frequency: 82.85%","Classroom size: 37<br />Common birthday frequency: 84.1%","Classroom size: 38<br />Common birthday frequency: 85.6%","Classroom size: 39<br />Common birthday frequency: 88.15%","Classroom size: 40<br />Common birthday frequency: 89.1%","Classroom size: 41<br />Common birthday frequency: 90%","Classroom size: 42<br />Common birthday frequency: 91.4%","Classroom size: 43<br />Common birthday frequency: 91.85%","Classroom size: 44<br />Common birthday frequency: 94.4%","Classroom size: 45<br />Common birthday frequency: 94.1%","Classroom size: 46<br />Common birthday frequency: 94%","Classroom size: 47<br />Common birthday frequency: 95.9%","Classroom size: 48<br />Common birthday frequency: 96.6%","Classroom size: 49<br />Common birthday frequency: 95.9%","Classroom size: 50<br />Common birthday frequency: 96.6%"],"type":"bar","textposition":"none","marker":{"autocolorscale":false,"color":"rgba(127,127,127,1)","line":{"width":1.8897637795275593,"color":"transparent"}},"name":"common.birthdays.freq","legendgroup":"common.birthdays.freq","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"orientation":"v","width":[0.90000000000000013,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.90000000000000036,0.89999999999999947,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.89999999999999858,0.90000000000000213,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568,0.90000000000000568],"base":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],"x":[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50],"y":[0.0044999999999999997,0.0025000000000000001,0.0050000000000000001,0.0155,0.017000000000000001,0.0155,0.017999999999999999,0.022499999999999999,0.023,0.023,0.029499999999999998,0.028000000000000001,0.034000000000000002,0.035999999999999997,0.035499999999999997,0.037499999999999999,0.041000000000000002,0.049000000000000002,0.052999999999999999,0.064000000000000001,0.058999999999999997,0.057000000000000002,0.057000000000000002,0.066000000000000003,0.068500000000000005,0.070000000000000007,0.068500000000000005,0.070000000000000007,0.084000000000000005,0.075999999999999998,0.086499999999999994,0.089499999999999996,0.092499999999999999,0.099000000000000005,0.092999999999999999,0.098000000000000004,0.088999999999999996,0.097500000000000003,0.1095,0.1065,0.10349999999999999,0.1045,0.106,0.1085,0.12,0.11749999999999999,0.11650000000000001,0.13550000000000001,0.11749999999999999],"text":["Classroom size: 2<br />Common birthday frequency: 0.45%","Classroom size: 3<br />Common birthday frequency: 0.25%","Classroom size: 4<br />Common birthday frequency: 0.5%","Classroom size: 5<br />Common birthday frequency: 1.55%","Classroom size: 6<br />Common birthday frequency: 1.7%","Classroom size: 7<br />Common birthday frequency: 1.55%","Classroom size: 8<br />Common birthday frequency: 1.8%","Classroom size: 9<br />Common birthday frequency: 2.25%","Classroom size: 10<br />Common birthday frequency: 2.3%","Classroom size: 11<br />Common birthday frequency: 2.3%","Classroom size: 12<br />Common birthday frequency: 2.95%","Classroom size: 13<br />Common birthday frequency: 2.8%","Classroom size: 14<br />Common birthday frequency: 3.4%","Classroom size: 15<br />Common birthday frequency: 3.6%","Classroom size: 16<br />Common birthday frequency: 3.55%","Classroom size: 17<br />Common birthday frequency: 3.75%","Classroom size: 18<br />Common birthday frequency: 4.1%","Classroom size: 19<br />Common birthday frequency: 4.9%","Classroom size: 20<br />Common birthday frequency: 5.3%","Classroom size: 21<br />Common birthday frequency: 6.4%","Classroom size: 22<br />Common birthday frequency: 5.9%","Classroom size: 23<br />Common birthday frequency: 5.7%","Classroom size: 24<br />Common birthday frequency: 5.7%","Classroom size: 25<br />Common birthday frequency: 6.6%","Classroom size: 26<br />Common birthday frequency: 6.85%","Classroom size: 27<br />Common birthday frequency: 7%","Classroom size: 28<br />Common birthday frequency: 6.85%","Classroom size: 29<br />Common birthday frequency: 7%","Classroom size: 30<br />Common birthday frequency: 8.4%","Classroom size: 31<br />Common birthday frequency: 7.6%","Classroom size: 32<br />Common birthday frequency: 8.65%","Classroom size: 33<br />Common birthday frequency: 8.95%","Classroom size: 34<br />Common birthday frequency: 9.25%","Classroom size: 35<br />Common birthday frequency: 9.9%","Classroom size: 36<br />Common birthday frequency: 9.3%","Classroom size: 37<br />Common birthday frequency: 9.8%","Classroom size: 38<br />Common birthday frequency: 8.9%","Classroom size: 39<br />Common birthday frequency: 9.75%","Classroom size: 40<br />Common birthday frequency: 10.95%","Classroom size: 41<br />Common birthday frequency: 10.65%","Classroom size: 42<br />Common birthday frequency: 10.35%","Classroom size: 43<br />Common birthday frequency: 10.45%","Classroom size: 44<br />Common birthday frequency: 10.6%","Classroom size: 45<br />Common birthday frequency: 10.85%","Classroom size: 46<br />Common birthday frequency: 12%","Classroom size: 47<br />Common birthday frequency: 11.75%","Classroom size: 48<br />Common birthday frequency: 11.65%","Classroom size: 49<br />Common birthday frequency: 13.55%","Classroom size: 50<br />Common birthday frequency: 11.75%"],"type":"bar","textposition":"none","marker":{"autocolorscale":false,"color":"rgba(0,205,0,1)","line":{"width":1.8897637795275593,"color":"transparent"}},"name":"common.birthday.specific.freq","legendgroup":"common.birthday.specific.freq","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1.55,50.450000000000003],"y":[0.5,0.5],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(0,0,0,1)","dash":"dash"},"hoveron":"points","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null}],"layout":{"margin":{"t":26.228310502283104,"r":7.3059360730593621,"b":48.418430884184303,"l":61.436280614362801},"plot_bgcolor":"rgba(216,216,216,1)","paper_bgcolor":"rgba(216,216,216,1)","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"xaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[1.55,50.450000000000003],"tickmode":"array","ticktext":["10","20","30","40","50"],"tickvals":[10,20,30,40,50],"categoryorder":"array","categoryarray":["10","20","30","40","50"],"nticks":null,"ticks":"outside","tickcolor":"rgba(51,51,51,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"y","title":{"text":"Classroom size (students)","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"yaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[0,1],"tickmode":"array","ticktext":["0%","25%","50%","75%","100%"],"tickvals":[0,0.25,0.5,0.75,1],"categoryorder":"array","categoryarray":["0%","25%","50%","75%","100%"],"nticks":null,"ticks":"outside","tickcolor":"rgba(51,51,51,1)","ticklen":3.6529680365296811,"tickwidth":0.66417600664176002,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":15.940224159402243},"tickangle":-0,"showline":true,"linecolor":"rgba(0,0,0,1)","linewidth":0.66417600664176002,"showgrid":false,"gridcolor":null,"gridwidth":0,"zeroline":false,"anchor":"x","title":{"text":"Frequency","font":{"color":"rgba(0,0,0,1)","family":"","size":18.596928185969279}},"hoverformat":".2f"},"shapes":[{"type":"rect","fillcolor":null,"line":{"color":null,"width":0,"linetype":[]},"yref":"paper","xref":"paper","x0":0,"x1":1,"y0":0,"y1":1}],"showlegend":false,"legend":{"bgcolor":"rgba(255,255,255,1)","bordercolor":"transparent","borderwidth":1.8897637795275593,"font":{"color":"rgba(0,0,0,1)","family":"","size":11.68949771689498}},"hovermode":"closest","barmode":"relative"},"config":{"doubleClick":"reset","modeBarButtonsToAdd":["hoverclosest","hovercompare"],"showSendToCloud":false,"displayModeBar":false},"source":"A","attrs":{"e505cee25f6":{"x":{},"y":{},"fill":{},"text":{},"type":"bar"},"e50e071a0c":{"yintercept":{}}},"cur_data":"e505cee25f6","visdat":{"e505cee25f6":["function (y) ","x"],"e50e071a0c":["function (y) ","x"]},"highlight":{"on":"plotly_click","persistent":false,"dynamic":false,"selectize":false,"opacityDim":0.20000000000000001,"selected":{"opacity":1},"debounce":0},"shinyEvents":["plotly_hover","plotly_click","plotly_selected","plotly_relayout","plotly_brushed","plotly_brushing","plotly_clickannotation","plotly_doubleclick","plotly_deselect","plotly_afterplot","plotly_sunburstclick"],"base_url":"https://plot.ly"},"evals":[],"jsHooks":[]}</script>

<p class="caption">

<span id="fig:unnamed-chunk-16"></span>Figure 4: Frequency of classrooms where there is at least one common birthday between <b>any</b> students (grey) <i>vs</i> with a <b>specific</b> student (green). Dashed horizontal line: 50%.
</p>

</div>

Some conclusions:

1.  For the smallest possible classroom (2 students) the two frequencies are exactly the same.

    This is not a statistical “accident”. If there are only 2 students (#1 and \#2), then the common birthday is **by definition** between these 2 students. Therefore, both frequencies have the same starting point.

2.  After that starting point, the increase of each frequency is very different:

    - The condition “any common birthday” seems to increase rapidly until it reaches a plateau.

    - The condition “same birthday as **me**” seems to increase with a more steady pace.

    The reason has to do with the underlying math, which is perhaps a story for another time…

## Getting to know your algorithms

Let’s zoom out a bit. When I stumbled upon this problem, I wondered *in just how many ways I can approach it*. The ways I can think of boil down to three algorithms:

1.  **Counting** or **brute force** ([failed](/posts/birthday-problem-1/)): lay down and analyze **all possible** combinations.

2.  **Sampling** (worked): draw and analyze a small **random sample** of all possible combinations.

3.  **Math**: find the **function** that gives the true probability for each classroom size, `\(P_{common~birthday}=f(classroom~size).\)` Barely qualifies as an algorithm. It’s mostly mental effort, and then just one calculation based on one number.

**Computational complexity** is “*the amount of resources required to run \[an algorithm\]*”, commonly referring to **time** and **data** (<a href="https://en.wikipedia.org/wiki/Computational_complexity" target="_blank">Wikipedia</a>).

A key difference between these algorithms is in their data requirements, or *space complexity*, and how they increase in relation to the input (classroom size).

| Method: | Counting | Sampling | Math |
|----|----|----|----|
| Aims for: | Precise probabilities | Approximate probabilities | Precise probabilities |
| Data required: | classroom size **·** 365<sup>classroom size</sup> | classroom size **·** 2 000 | 1 number (the classroom size itself) |
| Space complexity: | Exponential | Linear | Constant |

We could say that the space complexity shows the **personality** of each algorithm — something to keep in mind when choosing how to solve a problem:

- The counting method is strong but naive, thinking that *brute force* alone will achieve anything. In this case it failed because of its exponential space complexity, but for other problems it might work.

- The sampling method is a pragmatist, accepting limitations and getting to **a** solution, even if it’s not perfect. In this case it reduced space complexity to linear — sacrificing some precision, but it showed the pattern and that’s good enough.

- And the mathematical method is the smartest of the bunch, getting to the precise solution with no physical effort at all. But maybe we can’t spare the mental effort (at least for now…)

<details>

<summary>

Session info
</summary>

    ## R version 4.4.2 (2024-10-31 ucrt)
    ## Platform: x86_64-w64-mingw32/x64
    ## Running under: Windows 11 x64 (build 26100)
    ## 
    ## Matrix products: default
    ## 
    ## 
    ## locale:
    ## [1] LC_COLLATE=English_United States.utf8 
    ## [2] LC_CTYPE=English_United States.utf8   
    ## [3] LC_MONETARY=English_United States.utf8
    ## [4] LC_NUMERIC=C                          
    ## [5] LC_TIME=English_United States.utf8    
    ## 
    ## time zone: Europe/Stockholm
    ## tzcode source: internal
    ## 
    ## attached base packages:
    ## [1] stats     graphics  grDevices utils     datasets  methods   base     
    ## 
    ## other attached packages:
    ## [1] plotly_4.10.4     scales_1.3.0      ggthemes_5.1.0    ggplot2_3.5.1    
    ## [5] data.table_1.17.0 blogdown_1.20    
    ## 
    ## loaded via a namespace (and not attached):
    ##  [1] gtable_0.3.6      jsonlite_1.8.9    dplyr_1.1.4       compiler_4.4.2   
    ##  [5] tidyselect_1.2.1  stringr_1.5.1     tidyr_1.3.1       jquerylib_0.1.4  
    ##  [9] yaml_2.3.10       fastmap_1.2.0     R6_2.6.1          labeling_0.4.3   
    ## [13] generics_0.1.3    knitr_1.49        htmlwidgets_1.6.4 tibble_3.2.1     
    ## [17] bookdown_0.42     munsell_0.5.1     bslib_0.9.0       pillar_1.10.1    
    ## [21] rlang_1.1.4       cachem_1.1.0      stringi_1.8.4     xfun_0.49        
    ## [25] sass_0.4.9        lazyeval_0.2.2    viridisLite_0.4.2 cli_3.6.3        
    ## [29] withr_3.0.2       magrittr_2.0.3    crosstalk_1.2.1   digest_0.6.37    
    ## [33] grid_4.4.2        rstudioapi_0.17.1 lifecycle_1.0.4   vctrs_0.6.5      
    ## [37] evaluate_1.0.3    glue_1.8.0        colorspace_2.1-1  rmarkdown_2.29   
    ## [41] purrr_1.0.4       httr_1.4.7        tools_4.4.2       pkgconfig_2.0.3  
    ## [45] htmltools_0.5.8.1

</details>
