n <- 3:30
x <- 0:30

football.goals <- CJ(n=n,X=x)
football.goals.p <- data.table(n=n)
football.goals.p[,`:=`(p=mean.goals/n,
                       color="p<sub>goal</sub>")]
football.goals[,Probability.poisson:=dpois(x=X,lambda=mean.goals)]
football.goals[football.goals.p,
               `:=`(Probability.binom=dbinom(x=X,size=n,prob=p),
                    color=paste0("B(n=",n,",p=",(p |> round(digits=3) |> as.character()),")")),
               on="n"]

color.palette <- c("green4",rep("grey45",times=28))
names(color.palette) <- c("p<sub>goal</sub>",unique(football.goals[,color]))

football.figure <- plot_ly(frame=~n,colors=color.palette) |>
  add_trace(x=~X,y=~Probability.binom,data=football.goals,
            type="bar",color=~color) |>
  add_trace(x=~X,y=~Probability.poisson,data=football.goals,
            type="scatter",mode="lines+markers",color=I("black"),
            line=list(dash="dot",width=2),marker=list(size=12),name="Pois(λ=2.66)") |>
  add_segments(x=mean.goals,xend=mean.goals,y=0,yend=0.73,
               line=list(color="black",dash="dash"),name="Mean goals (2.66)") |>
  add_trace(x=~p,color=~color,data=football.goals.p,
            type="bar",xaxis="x2",yaxis="y2") |>
  layout(title=list(text="Probability of X goals in a football match",font=list(size=30)),
         barmode="stack",
         xaxis=list(title="Scored goals (X)",showgrid=FALSE,rangemode="tozero",
                    range=c(-0.5,30.5),ticks="outside",tick0=0,dtick=5),
         yaxis=list(title="Probability",showgrid=FALSE,rangemode="tozero",
                    linecolor="black",ticks="outside",tick0=0,dtick=0.1),
         xaxis2=list(domain=c(0.6, 0.95),anchor="y2",showgrid=FALSE,range=c(0,1),
                     ticks="inside",tick0=0,dtick=0.25),
         yaxis2=list(domain=c(0.7, 0.75),anchor="x2",showgrid=FALSE,visible=FALSE),
         legend=list(x=0.65,y=0.4,itemclick=FALSE,itemdoubleclick=FALSE),
         plot_bgcolor="#D8D8D8",paper_bgcolor="#D8D8D8",margin=list(t=80)) |>
  animation_slider(currentvalue=list(prefix="Time chunks (n): ",font=list(color="black"))) |>
  animation_button(visible=FALSE)

# Add main title
# Add frame to legend

football.figure
