library(ggplot2)
library(ggthemes)

results.plot <- simulated.summary |>
  ggplot(mapping=aes(x=goals,y=match.frequency,fill=(goals>6))) +
  theme_classic() +
  theme(panel.background=element_rect(fill="#D8D8D8"),
        plot.background=element_rect(fill="#D8D8D8",color="black"),
        legend.position="none") +
  labs(x="Scored goals",y="Frequency") +
  scale_x_continuous(expand=c(0,0),breaks=0:12) +
  scale_y_continuous(expand=c(0,0),breaks=(0:2)/10) +
  scale_fill_manual(values=c("grey35","green4")) +
  geom_col(width=1) +
  geom_vline(xintercept=2.66,linetype=2,linewidth=1)

library(plotly)

ggplotly(results.plot)