library(data.table)
library(extraDistr)

example.data <- CJ(shape=1:3,goals=0:15)
example.data[
  shape==1,
  prob:=dbbinom(x=goals,size=10,alpha=2*2.66/(10-2.66),beta=2)]
example.data[shape==2,prob:=dpois(x=goals,lambda=2.66)]
example.data[
  shape==3,
  prob:=
    lapply(X=goals,FUN=function(x){
      return(
        c(dbbinom(x=x,size=10,alpha=200*0.66/(10-0.66),beta=200),
          dbbinom(x=x,size=10,alpha=10000*4.66/(10-4.66),beta=10000)) |>
          mean()
      )}
    ) |> unlist()]

example.data[goals>6,
             prob.sum:=sum(prob) |> round(digits=3),
             by=shape]

library(ggplot2)
library(ggthemes)
library(gganimate)

initial.plot <- example.data |>
  ggplot(mapping=aes(x=goals,y=prob,color=(goals>6))) +
  theme_classic() +
  theme(panel.background=element_rect(fill="#D8D8D8"),
        plot.background=element_rect(fill="#D8D8D8",color="black")) +
  labs(x="Scored goals",y="Probability") +
  scale_x_continuous(limits=c(-0.5,15.5),expand=c(0,0),breaks=0:15) +
  scale_y_continuous(expand=expansion(mult=c(0,0.05)),breaks=(0:2)/10) +
  scale_color_manual(values=c("grey30","green3")) +
  theme(legend.position="none") +
  geom_line(color="black",linetype="dotted",linewidth=1) +
  geom_point(size=8) +
  geom_vline(xintercept=2.66,linetype=2,linewidth=1.5) +
  geom_text(x=2.66,y=0.25,label="Mean: 2.66",hjust=-0.20,check_overlap=TRUE,inherit.aes=FALSE) +
  geom_text(x=7,y=0.23,size=10,mapping=aes(label=paste("Scenario",shape)),
            hjust=0,inherit.aes=FALSE,check_overlap=TRUE) +
  geom_label(x=7,y=0.15,hjust=0,fill="green3",inherit.aes=FALSE,
             mapping=aes(label=paste0("P(more than 6 goals) = ",prob.sum))) +
  transition_states(states=shape,transition_length=0.5,state_length=3)

initial.plot |>
  animate(nframes=160,fps=20) |>
  anim_save(filename="images/intro_figure.gif",animation=_)
