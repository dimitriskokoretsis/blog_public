n <- 1:30
x <- 0:30

coin.flips <- CJ(n=n,X=x)
coin.flips[,color:=paste0("B(n=",n,",p=0.5)")]
coin.flips.p <- CJ(n=n,Heads=0.5)
coin.flips[coin.flips.p,
           Probability:=dbinom(x=X,size=n,prob=Heads),
           on="n"]
coin.flips.p[,`:=`(mean.heads=n/2,color="p<sub>success</sub>")]

color.palette <- c("green4",rep("grey45",times=30))
names(color.palette) <- c("p<sub>success</sub>",paste0("B(n=",n,",p=0.5)"))

coin.figure <- plot_ly(frame=~n,colors=color.palette) |>
  add_trace(x=~X,y=~Probability,data=coin.flips,
            type="bar",color=~color) |>
  add_segments(x=~mean.heads,xend=~mean.heads,y=0,yend=0.53,
               data=coin.flips.p,line=list(color="black",dash="dash"),
               name="Mean successes") |>
  add_trace(x=~Heads,color=~color,data=coin.flips.p,
            type="bar",xaxis="x2",yaxis="y2") |>
  layout(title=list(text="Probability of X successes in n coin flips",font=list(size=30)),
         barmode="stack",
         xaxis=list(title="Number of successes (X)",showgrid=FALSE,rangemode="tozero",
                    ticks="outside",tick0=0,dtick=5),
         yaxis=list(title="Probability",showgrid=FALSE,rangemode="tozero",
                    linecolor="black",ticks="outside",tick0=0,dtick=0.1),
         xaxis2=list(domain=c(0.6, 0.95),anchor="y2",showgrid=FALSE,range=c(0,1),
                     ticks="inside",tick0=0,dtick=0.25),
         yaxis2=list(domain=c(0.7, 0.75),anchor="x2",showgrid=FALSE,visible=FALSE),
         legend=list(x=0.65,y=0.4,itemclick=FALSE,itemdoubleclick=FALSE),
         plot_bgcolor="#D8D8D8",paper_bgcolor="#D8D8D8",margin=list(t=80)) |>
  animation_slider(currentvalue=list(prefix="Coin flips (n): ",font=list(color="black"))) |>
  animation_button(visible=FALSE)

coin.figure
